import { DemoPipe } from './demo.pipe';

describe('DemoPipe', () => {
  it('create an instance', () => {
    const pipe = new DemoPipe();
    expect(pipe).toBeTruthy();
    expect(pipe.transform(222,60)).toEqual(282);
  });
});
