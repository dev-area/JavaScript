import { TestBed, inject } from '@angular/core/testing';

import { SimpService } from './simp.service';

describe('SimpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SimpService]
    });
  });

  it('should be created', inject([SimpService], (service: SimpService) => {
    expect(service).toBeTruthy();
    expect(service.add(100,200)).toEqual(300);
  }));
});
