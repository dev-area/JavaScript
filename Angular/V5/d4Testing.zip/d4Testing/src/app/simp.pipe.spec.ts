import { SimpPipe } from './simp.pipe';

describe('SimpPipe', () => {
  it('create an instance', () => {
    const pipe = new SimpPipe();
    expect(pipe).toBeTruthy();
    expect(pipe.transform(100,200)).toEqual(400)
  });
});
