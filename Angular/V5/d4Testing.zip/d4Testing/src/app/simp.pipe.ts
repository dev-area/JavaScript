import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'simp'
})
export class SimpPipe implements PipeTransform {

  transform(value: number, n1: number): number {
    return value+n1+100;
  }

}
