import { Component } from '@angular/core';
import {Question} from './Question';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Math test!';
  results: Array<Question>;
  res1: number[];
  qnum: number = 0;
  op1: string = "*";
  totalgrade: number = 0;

  onGenClick(val) {
    let i: number;
    this.results = new Array<Question>(val);
    for (i = 0; i < val; i++) {
      this.results[i] = new Question();
    }
    this.qnum = val;
  }
  onGenCheck() {
    let s: number = 0;
    for (let i = 0; i < this.results.length; i++) {
      if (this.results[i].userResult == this.results[i].result)
      {
        this.results[i].resCheck = 0;
        s++;
      }
      else
        this.results[i].resCheck = 1;
    }
    this.totalgrade = s / this.results.length * 100;
  }
}
