import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from "@angular/forms";
import { ExamHeaderComponent } from './exam-header/exam-header.component';
import { MathQuestionComponent } from './math-question/math-question.component';

@NgModule({
  declarations: [
    AppComponent,
    ExamHeaderComponent,
    MathQuestionComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
