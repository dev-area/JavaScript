import { Component, OnInit, Input, Output ,EventEmitter} from '@angular/core';


@Component({
  selector: 'app-math-question',
  templateUrl: './math-question.component.html',
  styleUrls: ['./math-question.component.css']
})
export class MathQuestionComponent implements OnInit{
  ngOnInit(): void {

  }

  @Input() num1: number;
  @Input() num2: number;
  @Input() op: string;
  @Input() answer: string;
  res: number;

  @Input()
  set ansOK(val: string) {
    console.log(val);
    switch (val) {
      case '0':
        this.answer = 'greenyellow';
        break;
      case '1':
        this.answer = 'red';
        break;
      case '2':
        this.answer = 'white';
        break;
    }
  }


  @Output() resultChange = new EventEmitter();

  @Input()
  set result(val) {
    this.res = val;
    this.resultChange.emit(val);
  }
  get result() {
    return this.res;
  }
  constructor() {
    this.num1 = this.num2 = 0;
  }


}
