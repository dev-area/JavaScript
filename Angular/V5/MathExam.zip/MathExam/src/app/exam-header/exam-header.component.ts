import { Component, OnInit , EventEmitter, Output,Input} from '@angular/core';

@Component({
  selector: 'app-exam-header',
  templateUrl: './exam-header.component.html',
  styleUrls: ['./exam-header.component.css']
})
export class ExamHeaderComponent {

  num: number;
  @Input() grade: number;

  @Output() genClick: EventEmitter<number> = new EventEmitter<number>();

  setNum() {
    this.genClick.emit(this.num);
  }
  @Output() genCheck = new EventEmitter();

  setCheck() {
    this.genCheck.emit();
  }



}
