export class Question {
  num1: number;
  num2: number;
  op: OP;
  result: number;
  userResult: number;
  resCheck: number;

  constructor() {
    this.fillQuestion();
  }
  static genNumber(limit): number {
    return Math.floor(Math.random() * limit + 1);
  }
  static genOP(): OP {
    let n = Math.floor(Math.random() * 4 + 1);
    switch (n) {
      case 1:
        return OP.ADD;
      case 2:
        return OP.SUB;
      case 3:
        return OP.MUL;
      case 4:
        return OP.DIV;
    }
  }
  getOPSymbol(): string {
    switch (this.op) {
      case OP.ADD:
        return '+';
      case OP.SUB:
        return '-';
      case OP.MUL:
        return '*';
      case OP.DIV:
        return '/';
    }

  }
  fillQuestion() {
    this.num1 = Question.genNumber(100);
    this.num2 = Question.genNumber(100);
    this.op = Question.genOP();
    this.resCheck = 2;
    switch (this.op) {
      case OP.ADD:
        this.result = this.num1 + this.num2;
        break;
      case OP.SUB:
        this.result = this.num1 - this.num2;
        break;
      case OP.MUL:
        this.result = this.num1 * this.num2;
        break;
      case OP.DIV:
        this.result = this.num1 / this.num2;
        break;
    }
  }
}

export enum OP{ ADD, SUB, MUL, DIV };
