import { Component } from '@angular/core';
import {NgForm} from "@angular/forms";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user = {
    username: 'Chris',
    email: 'chris@google.com',
    password: 'test',
    gender: 'male',
    role: 'guest',
    vip: true
  };

  genders = [
    'male',
    'female'
  ];

  roles = [
    { value: 'admin', display: 'Administrator' },
    { value: 'guest', display: 'Guest' },
    { value: 'custom', display: 'Custom' }
  ];

  onSubmit(form: NgForm) {
    console.log(form.value);
  }
}
