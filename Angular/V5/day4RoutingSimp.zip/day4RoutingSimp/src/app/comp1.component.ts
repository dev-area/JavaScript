import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp1',
  template: `
    <h3>
      comp1 works!
    </h3>
  `,
  styles: []
})
export class Comp1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
