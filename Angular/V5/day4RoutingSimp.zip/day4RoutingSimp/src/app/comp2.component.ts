import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp2',
  template: `
    <h3>
      comp2 works!
    </h3>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class Comp2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
