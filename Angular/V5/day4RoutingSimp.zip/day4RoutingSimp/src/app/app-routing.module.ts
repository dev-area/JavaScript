import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {Comp1Component} from "./comp1.component";
import {Comp2Component} from "./comp2.component";
import {Comp3Component} from "./comp3.component";
import {Comp4Component} from "./comp4.component";
import {Comp5Component} from "./comp5.component";
import {Comp6Component} from "./comp6.component";

const routes: Routes = [
  {
    path: '',
    component: Comp1Component
  },
  {
    path: 'books',
    component:Comp2Component,
    children: [
      {
        path: '',
        component: Comp5Component
      },
      {
        path: 'search',
        component: Comp6Component
      }
    ]
  },
  {
    path: 'customers',
    component:Comp3Component,
    children: [
      {
        path: '',
        component: Comp5Component
      },
      {
        path: 'search',
        component: Comp6Component
      }
    ]
  },
  {
    path: 'loans',
    component:Comp4Component
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
