import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp6',
  template: `
    <p>
      comp6 works!
    </p>
  `,
  styles: []
})
export class Comp6Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
