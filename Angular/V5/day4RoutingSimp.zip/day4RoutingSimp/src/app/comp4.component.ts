import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp4',
  template: `
    <h4>
      comp4 works!
    </h4>
  `,
  styles: []
})
export class Comp4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
