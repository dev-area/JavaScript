import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp3',
  template: `
    <h3>
      comp3 works!
    </h3>
    <a routerLink="add">Add New</a>
    <a routerLink="search">Search</a>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class Comp3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
