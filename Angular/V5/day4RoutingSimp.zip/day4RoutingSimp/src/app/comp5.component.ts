import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp5',
  template: `
    <p>
      comp5 works!
    </p>
  `,
  styles: []
})
export class Comp5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
