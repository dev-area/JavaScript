import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { CustomersComponent } from './customers/customers.component';
import { LoansComponent } from './loans/loans.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { BooksService } from "./books.service";
import { BooksFilterPipe } from './books-filter.pipe';
import { CustomersService } from "./customers.service";
import { LoanslistComponent } from './loans/loanslist.component';
import { LoandetailsComponent } from './loans/loandetails.component';
import { LoanordersComponent } from './loans/loanorders.component';
import { LoansalertsComponent } from './loans/loansalerts.component';
import { LoansService } from "./loans.service";
import {Ng2OrderModule} from "ng2-order-pipe";

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    CustomersComponent,
    LoansComponent,
    WelcomeComponent,
    BooksFilterPipe,
    LoanslistComponent,
    LoandetailsComponent,
    LoanordersComponent,
    LoansalertsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    Ng2OrderModule
  ],
  providers: [BooksService,CustomersService,LoansService],
  bootstrap: [AppComponent]
})
export class AppModule { }
