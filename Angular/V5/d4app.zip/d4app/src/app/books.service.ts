import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';

import {Observable} from 'rxjs';
import {Book} from './books/book';
import 'rxjs/add/operator/map';



@Injectable()
export class BooksService {
  next:number = 100;
  constructor(private _http:Http) { }

  getData():Observable<Book[]>{
      return this._http.get("http://localhost:3000/books").map(r => <Book[]>r.json());
  }

  AddBook(_name:string,_price:number,_rate:number):Observable<Book[]>{
     return this._http.post("http://localhost:3000/books", {id:this.next++, Name: _name, Price: _price, rate:_rate})
           .map( (res: Response) => res.json() );
  }
  DeleteBook(_id:number): Observable<any>{
    return this._http.delete("http://localhost:3000/books/"+_id);
 }
  
}
