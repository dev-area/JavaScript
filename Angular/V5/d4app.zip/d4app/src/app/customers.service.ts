import { Injectable } from '@angular/core';
import { Http , Response} from "@angular/http";
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import { Customer } from "app/customers/customer";


@Injectable()
export class CustomersService {

  constructor(private _http:Http) { }

  getData():Observable<Customer[]>{
      return this._http.get("http://localhost:3000/customers").map(r => <Customer[]>r.json());
  }

}
