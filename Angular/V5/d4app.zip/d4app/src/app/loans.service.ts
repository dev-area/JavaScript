import { Injectable } from '@angular/core';
import { Http , Response} from "@angular/http";
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import { Loan } from "app/loans/loan";

@Injectable()
export class LoansService {

  constructor(private _http:Http) { }

  getData():Observable<Loan[]>{
      return this._http.get("http://localhost:3000/loans").map(r => <Loan[]>r.json());
  }

}
