export class Loan{
    id:number;
    booknum:number;
    custnum:number;
    date:string;
}