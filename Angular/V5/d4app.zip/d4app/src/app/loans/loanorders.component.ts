import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanorderd',
  template: `
    <p>
      loanorderd Works!
    </p>
  `,
  styles: []
})
export class LoanordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
