import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-loandetails',
  template: `
    <h1>
      Details
    </h1>
    <p>
    Loan ID: {{id}}
    </p>
  `,
  styles: []
})
export class LoandetailsComponent implements OnInit {
  id:number;
      
  constructor(private rt:ActivatedRoute) { }

  ngOnInit() {
    this.id = this.rt.snapshot.params['id'];
  }


}
