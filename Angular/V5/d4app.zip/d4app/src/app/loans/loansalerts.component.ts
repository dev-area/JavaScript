import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loansalerts',
  template: `
    <p>
      loansalerts Works!
    </p>
  `,
  styles: []
})
export class LoansalertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
