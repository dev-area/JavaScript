import { Component, OnInit } from '@angular/core';
import { Loan } from "app/loans/loan";
import { LoansService } from "app/loans.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-loanslist',
  template: `
    <table  class="table" *ngIf='loans && loans.length > 0'>
        <thead >
          <tr class="bg-primary">
            <th>Book ID</th>
            <th>Customer ID</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
            <tr *ngFor='let c of loans'>
                <td> {{c.booknum}} </td>
                <td> {{c.custnum}} </td>
                <td> <button class="btn btn-outline-success" (click)='details(c.id)'>Detsils</button></td>
            </tr>
        </tbody> 
</table>
  `,
  styles: []
})
export class LoanslistComponent implements OnInit {

  loans:Loan[];
  

  constructor(private ser:LoansService, private rt:Router) { }
  
  details(i){
      this.rt.navigate(['loans/details/' + i]);
  }

  

  getAll()
  {
    this.ser.getData().subscribe(c => this.loans = c);
  }

  ngOnInit() {
    this.getAll();
  }

}
