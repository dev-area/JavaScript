import { Pipe, PipeTransform } from '@angular/core';
import { Book } from "app/books/book";

@Pipe({
  name: 'booksFilter'
})
export class BooksFilterPipe implements PipeTransform {

  transform(value: any, fil: string): Book[] {
    fil = fil.toLowerCase();
    return value.filter(c => c.Name.toLocaleLowerCase().indexOf(fil) >= 0);
 }

}
