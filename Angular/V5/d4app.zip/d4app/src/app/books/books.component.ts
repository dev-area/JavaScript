import { Component, OnInit } from '@angular/core';
import { Book } from "./book";
import { BooksService } from "../books.service";

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  books:Book[];
  filter:string="";

  order:string = 'Price';

  setOrder(s:string){
    this.order = s;
  }

  constructor(private ser:BooksService) { }

  createBook(name:string, price:number, rate:number)
  {
    this.ser.AddBook(name,price,rate).subscribe(r => this.getAll());
  }

  getAll()
  {
    this.ser.getData().subscribe(b => this.books = b);
  }
  delete(id:number)
  {
    this.ser.DeleteBook(id).subscribe(
      data => {
        this.getAll();
      }
    );
  }
  ngOnInit() {
    this.getAll();
  }

}
