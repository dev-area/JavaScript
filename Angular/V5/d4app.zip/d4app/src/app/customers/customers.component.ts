import { Component, OnInit } from '@angular/core';
import { Customer } from "app/customers/customer";
import { CustomersService } from "app/customers.service";

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  cust:Customer[];
  
  order:string = 'Name';

  setOrder(s:string){
    this.order = s;
  }

  constructor(private ser:CustomersService) { }
  
  

  getAll()
  {
    this.ser.getData().subscribe(c => this.cust = c);
  }

  ngOnInit() {
    this.getAll();
  }


}
