export class Customer{
    id: number;
    Name: string;
    city: string;
}