import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BooksComponent} from './books/books.component';
import {CustomersComponent} from './customers/customers.component';
import {LoansComponent} from './loans/loans.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoandetailsComponent } from "./loans/loandetails.component";
import { LoanslistComponent } from "./loans/loanslist.component";
import { LoanordersComponent } from "./loans/loanorders.component";
import { LoansalertsComponent } from "./loans/loansalerts.component";

const routes: Routes = [
  {
            path: '',
            component: WelcomeComponent
        },
        {
            path: 'books',
            component: BooksComponent
        },
        {
            path: 'customers',
            component: CustomersComponent,
        },
        {
            path: 'loans',
            component: LoansComponent,
            children: [
              {
                    path: '',
                    component: LoanslistComponent
                },
                {
                    path: 'details/:id',
                    component: LoandetailsComponent
                },
                {
                    path: 'orders',
                    component: LoanordersComponent
                },
                {
                    path: 'alerts',
                    component: LoansalertsComponent
                }

            ]
        }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule { }
