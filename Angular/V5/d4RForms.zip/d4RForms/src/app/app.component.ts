import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators, FormBuilder, FormArray} from "@angular/forms";
import { Observable } from "rxjs/Rx";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  myForm: FormGroup;

  genders = [
    'male',
    'female'
  ];

  constructor(private formBuilder: FormBuilder) {
/*     this.myForm = new FormGroup({
       'userData': new FormGroup({
         'username': new FormControl('Chris', Validators.required),
         'email': new FormControl('', [
           Validators.required,
           Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
         ])
       }),
       'password': new FormControl('', Validators.required),
       'gender': new FormControl('male'),
       'hobbies': new FormArray([
         new FormControl('Cooking', Validators.required)
       ])
     });
*/
    this.myForm = formBuilder.group({
      'userData': formBuilder.group({
        'username': ['Chris', [Validators.required, this.exampleValidator]],
        'email': ['chris@google.com', [
          Validators.required,
          Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
        ]]
      }),
      'password': ['', Validators.required],
      'gender': ['male'],
      'hobbies': formBuilder.array([
        ['Cooking', Validators.required]
      ])
    });

    this.myForm.valueChanges
      .subscribe((value => console.log("change:"+ value)));

    this.myForm.statusChanges.subscribe(
      (data: any) => {
        console.log(data)
        console.log(this.myForm.controls.userData.get('username').errors);

      }

    );
  }

  onAutofill()
  {
    this.myForm.patchValue({"userData":{"username":"Elvis","email":"elvis@google.com"},"password":"abcde","gender":"male","hobbies":["Singing","Dancing"]});
  }
  onNameFill(){
    this.myForm.patchValue({"userData":{"username":"Elvis"}});
  }
  onAddHobby() {
    (<FormArray>this.myForm.controls['hobbies']).push(new FormControl('', Validators.required));
  }

  onSubmit() {
    console.log(this.myForm);
  }

  exampleValidator(control: FormControl): {[s: string]: boolean} {
    if (control.value == 'Example') {
      return {'haserror': true};
    }
    return null;
  }



}
