import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {SimpModModule} from "./simp-mod/simp-mod.module";
import { Comp2Component } from './comp2/comp2.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    SimpModModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
