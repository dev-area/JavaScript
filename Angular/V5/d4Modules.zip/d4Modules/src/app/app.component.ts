import { Component } from '@angular/core';
import {SimpService} from "./simp.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  num:number;
  constructor(private _ser:SimpService){}
  onser()
  {
    this.num = this._ser.add(100,200);
  }
}
