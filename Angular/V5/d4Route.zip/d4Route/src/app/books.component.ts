import { Component, OnInit ,OnDestroy} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs/Rx';

@Component({
  selector: 'app-books',
  template: `
    <p>
      book List! {{qnum}}
    </p>
    <button (click)="oncl2()">inner</button>
    <input type="text" [(ngModel)]='num' /><br/>
     <button (click)="oncl3()">inner</button><br/>
     <a class='nav-link' routerLink="/customers" [queryParamsHandling]="'merge'" >Customers</a>

    <table align="center" border='1' width='80%' *ngIf='books && books.length > 0'>
        <thead>
          <tr>
            <td>ID</td>
            <td>Name</td>
            <td>Price</td>
            <td>Rate</td>
            <td>Details</td>
            <td>Details</td>
          </tr>
        </thead>
        <tbody>
            <tr *ngFor='let b of books'>
                <td> {{b.Id}} </td>
                <td> {{b.Name }} </td>
                <td> {{b.Price}} </td>
                <td> {{b.Rate}} </td>
                <td> <a [routerLink]="['/book',b.Id,b.Price]">Details</a> </td>
                <td> <button (click)="onclick(b.Id,b.Price)">click</button>
            </tr>
        </tbody> 
    </table>
    
  `,
  styles: []
})
export class BooksComponent implements OnDestroy{
  qnum:number;

  query_sub:Subscription;
  fragment_sub:Subscription;

  constructor(private _router:Router, private _activeRoute:ActivatedRoute){

    this.query_sub = _activeRoute.queryParams
      .subscribe(qp => this.qnum = qp['val']);

    this.fragment_sub = _activeRoute.fragment.subscribe(
      fragment => console.log(fragment)
    );
  }
  ngOnDestroy()
  {
    this.query_sub.unsubscribe();
    this.fragment_sub.unsubscribe();
  }
  onclick(i,n){
    this._router.navigate(['book' , i ,  n]);
  }

  num:number;

  oncl2(){
    this._router.navigate(['books'],{queryParams:{'val': this.num}});
  }
  oncl3(){
    this._router.navigate(['books'],{fragment:'aaa'});
  }
  books:Book [] = [
    {
      "Id": 100,
      "Name": "book1",
      "Price": 123,
      "Rate": 3
    },
    {
      "Id": 200,
      "Name": "book2",
      "Price": 230,
      "Rate": 5,
    },
    {
      "Id": 300,
      "Name": "book3",
      "Price": 150,
      "Rate": 5,
    },
    {
      "Id": 400,
      "Name": "book4",
      "Price": 250,
      "Rate": 4
    },

  ];


}

export class Book {
  Id:number;
  Name:string;
  Price:number;
  Rate:number;
}
