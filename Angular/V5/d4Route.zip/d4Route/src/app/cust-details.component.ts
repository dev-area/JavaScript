import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-details',
  template: `
    <p>
      cust-details works!
    </p>
  `,
  styles: []
})
export class CustDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
