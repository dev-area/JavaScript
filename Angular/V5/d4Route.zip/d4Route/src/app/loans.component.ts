import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans',
  template: `
    <p>
      loans works!
    </p>
  `,
  styles: []
})
export class LoansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
