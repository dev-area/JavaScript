import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers',
  template: `
    <p>
      customers Works!
    </p>
    <a routerLink="edit">Edit</a>  
    <a routerLink="details">details</a>
    <br/><br/>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class CustomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
