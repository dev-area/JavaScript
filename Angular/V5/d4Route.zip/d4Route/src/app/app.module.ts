import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BooksComponent } from './books.component';
import { CustomersComponent } from './customers.component';
import { LoansComponent } from './loans.component';
import { WelcomeComponent } from './welcome.component';
import { BookDetailsComponent } from './book-details.component';
import { CustDetailsComponent } from './cust-details.component';
import { CustEditComponent } from './cust-edit.component';
import {routing} from "./app.routing";
import {BookGuard} from "./book.guard";
import {FormsModule} from "@angular/forms";
import { PageNotFoundComponent } from './page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    CustomersComponent,
    LoansComponent,
    WelcomeComponent,
    BookDetailsComponent,
    CustDetailsComponent,
    CustEditComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule
  ],
  providers: [BookGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
