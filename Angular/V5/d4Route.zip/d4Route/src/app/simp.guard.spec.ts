import { TestBed, async, inject } from '@angular/core/testing';

import { SimpGuard } from './simp.guard';

describe('SimpGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SimpGuard]
    });
  });

  it('should ...', inject([SimpGuard], (guard: SimpGuard) => {
    expect(guard).toBeTruthy();
  }));
});
