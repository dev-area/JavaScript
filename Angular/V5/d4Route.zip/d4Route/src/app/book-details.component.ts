import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-book-details',
  template: `
    <br/>
      <h3>book-details:<br/><br/> id: {{id}}
      <br/>
      Price: {{n1}}
      </h3>
      
    
  `,
  styles: []
})
export class BookDetailsComponent implements OnInit {
  id:number;
  n1:number;
  constructor(private _activeRoute:ActivatedRoute) { }

  ngOnInit() {
    this.id = this._activeRoute.snapshot.params['id'];
    this.n1 = this._activeRoute.snapshot.params['price'];
  }

}
