import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {BooksComponent} from './books.component';
import {CustomersComponent} from './customers.component';
import {LoansComponent} from './loans.component';
import {WelcomeComponent} from './welcome.component';
import {BookDetailsComponent} from './book-details.component';
import {CustDetailsComponent} from './cust-details.component';
import {CustEditComponent} from './cust-edit.component';
import {BookGuard } from './book.guard';
import {PageNotFoundComponent} from "./page-not-found.component";


const appRoutes : Routes =
  [
    {
      path: '',
      component: WelcomeComponent
    },
    {
      path: 'books',
      component: BooksComponent
    },
    {
      path: 'customers',
      component: CustomersComponent,
      children: [
        {
          path: 'edit',
          component: CustEditComponent
        },
        {
          path: 'details',
          component: CustDetailsComponent
        }
      ]
    },
    {
      path: 'loans',
      component: LoansComponent,

    },
    {
      path: 'book/:id/:price',
      component: BookDetailsComponent,
      canActivate: [BookGuard]
    },
    {
      path: '**',
      component: PageNotFoundComponent
    }
  ];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);

