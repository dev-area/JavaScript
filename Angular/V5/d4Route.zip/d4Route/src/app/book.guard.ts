import { Injectable } from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot} from '@angular/router';

@Injectable()
export class BookGuard implements CanActivate {

  constructor() { }

  canActivate(_route: ActivatedRouteSnapshot): boolean {
    let price = +_route.url[2].path;
    console.log(_route.url[0])
    if (price > 200)
      return false;
    return true;
  }

}
