import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-edit',
  template: `
    <p>
      cust-edit works!
    </p>
  `,
  styles: []
})
export class CustEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
