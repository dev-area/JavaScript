export interface Book{
    id:number;
    Name:string;
    Price:number;
    rate:number;
}